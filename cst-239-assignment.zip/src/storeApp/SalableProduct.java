package storeApp;
import storeContents.InventoryManager;
import storeContents.ShoppingCart;

/**

The SalableProduct class represents a product that can be sold in the store.

*It has a name, description, price and quantity.
*/

public class SalableProduct {
    private String name;
    private String description;
    private double price;
    private int quantity;
    
    /**

    Constructor for a SalableProduct.
    @param name the name of the product
    @param description the description of the product
    @param price the price of the product
    @param quantity the quantity of the product
    */

    public SalableProduct(String name, String description, double price, int quantity) {
        this.name = name;
        this.description = description;
        this.price = price;
        this.quantity = quantity;
    }
    
    /**

    Get the name of the product.
    @return the name of the product
    */

    public String getName() {
        return name;
    }

    /**

    Get the description of the product.
    @return the description of the product
    */
    
    public String getDescription() {
        return description;
    }
    
    /**

    Get the price of the product.
    @return the price of the product
    */

    public double getPrice() {
        return price;
    }
    
    /**

    Get the quantity of the product.
    @return the quantity of the product
    */

    public int getQuantity() {
        return quantity;
    }

    /**

    Set the quantity of the product.
    @param quantity the new quantity of the product
    */
    
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
    
    /**

    Get the SalableProduct with the specified name.
    @param itemName the name of the SalableProduct to get
    @return the SalableProduct with the specified name
    */
    public SalableProduct getSalableProduct(String itemName) {
    	
    	   for (SalableProduct product : salableProduct) {
    	      if (product.getName().equals(itemName)) {
    	         return product;
    	      }
    	   }
    }
}