package storeApp;
import java.util.Scanner;

import storeContents.InventoryManager;
import storeContents.ShoppingCart;

/** This class will allow a user to add items to a shopping cart, purchase items, or cancel the shop sale
 * 
 * @author rargueta
 *
 */

public class StoreFrontApplication {
	
	private StoreFrontApplication storeFront;
	private InventoryManager inventoryManager;
	private ShoppingCart shoppingCart;
	private SalableProduct[] salableProducts;

	/**
	 * Returns the array of SalableProducts available for sale in the store.
	 *
	 * @return the array of SalableProducts available for sale in the store
	 */
    public SalableProduct[] getSalableProducts() {
        return salableProducts;
    }

    
	public StoreFrontApplication(SalableProduct[] products) {
		this.salableProducts = products;
	    inventoryManager = new InventoryManager(storeFront);
	    shoppingCart = new ShoppingCart();
	}
	
	/**
     * The main method of the StoreFrontApplication, which displays the main menu and performs actions based on user input.
     */

	public static void main(String[] args) {
	    // Create the salable products available in the store
	    SalableProduct[] products = new SalableProduct[] {
	            new SalableProduct("Spear", "A long, pointed weapon", 100, 10),
	            new SalableProduct("Sword", "A weapon with a long metal blade and a handguard", 150, 8),
	            new SalableProduct("Helmet", "A piece of armor that covers the head", 50, 15),
	            new SalableProduct("Chainmail", "Armor made of interlocking rings designed to protect the chest", 200, 5),
	            new SalableProduct("Boots", "Protective footgear", 75, 12),
	            new SalableProduct("Potion", "A magical liquid that restores health", 25, 20),
	            new SalableProduct("Ginseng", "A root with healing properties", 10, 30)
	    };
	    
	    StoreFrontApplication storeFrontApp = new StoreFrontApplication(products);
	    Scanner scanner = new Scanner(System.in);

	    System.out.println("Welcome to the store!");

	    while (true) {
	        // Display the main menu
	        System.out.println("Please select an option:");
	        System.out.println("1. Display items for sale");
	        System.out.println("2. Purchase an item");
	        System.out.println("3. Cancel a purchase");
	        System.out.println("4. View shopping cart");
	        System.out.println("5. Exit");

	        // Get user input
	        int choice = scanner.nextInt();
	        scanner.nextLine(); // Consume the newline character

	        switch (choice) {
	            case 1:
	                storeFrontApp.displayItems();
	                break;
	            case 2:
	                storeFrontApp.purchaseItem(scanner);
	                break;
	            case 3:
	                storeFrontApp.cancelPurchase(scanner);
	                break;
	            case 4:
	                storeFrontApp.viewShoppingCart();
	                break;
	            case 5:
	                System.out.println("Thanks for your purchase!");
	                return;
	            default:
	                System.out.println("Invalid option. Please try again.");
	                break;
	        }
	    }
	}

	/**
	 * This will display items for sale to the user
	 */
	public void displayItems() {
	    SalableProduct[] products = storeFront.getSalableProducts();
	    System.out.println("Items for sale:");
	    for (SalableProduct product : products) {
	        System.out.println(product.getName() + " - " + product.getDescription() + " - $" + product.getPrice()
	                + " - Quantity available: " + inventoryManager.getQuantity(product.getName()));
	    }
	}

	/**
	 * This will allow an item to be purchased by the user
	 *
	 * @param scanner the Scanner object used to get user input
	 */
	public void purchaseItem() {
	   
	    SalableProduct product = storeFront.getSalableProduct(itemName);
	    int quantityAvailable = inventoryManager.getQuantity(itemName);

	    System.out.println("Please enter the quantity you want to purchase: ");
	    int quantity = scanner.nextInt();
	    scanner.nextLine(); 

	    // Check if there is enough quantity of the item available
	    if (quantity > quantityAvailable) {
	    	System.out.println("Sorry, it seems there aren't enough available.");
	    	return;
	    }
	}
	    /**

	    This will cancel a purchase for the user

	    @param scanner the Scanner object used to get user input
	    */
	    public void cancelPurchase(Scanner scanner) {
	    // Display the items in the shopping cart
	    SalableProduct[] products = shoppingCart.getProducts();
	    if (products.length == 0) {
	    System.out.println("Your shopping cart is empty.");
	    return;
	    }

	    // Remove the item from the shopping cart
	    shoppingCart.removeProduct(product);

	    // Update the inventory manager
	    inventoryManager.updateQuantity(itemName, quantityInCart);

	    System.out.println(quantityInCart + " " + itemName + "(s) removed from your shopping cart.");
	    }
	

	    /**

	    This will display the contents of the shopping cart to the user
	    */
	    public void viewShoppingCart() {
	    SalableProduct[] products = shoppingCart.getProducts();
	    if (products.length == 0) {
	    System.out.println("Your shopping cart is empty.");
	    return;
	    }

	    System.out.println("Items in your shopping cart:");
	    for (SalableProduct product : products) {
	    System.out.println(product.getName() + " - Quantity: " + shoppingCart.getQuantity(product));
	    }
	}
}