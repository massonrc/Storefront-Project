package storeContents;

import java.util.HashMap;
import java.util.Map;

import storeApp.SalableProduct;
import storeApp.StoreFrontApplication;

public class InventoryManager {
    private Map<String, Integer> inventory;

    public InventoryManager(StoreFrontApplication storeFront) {
        this.inventory = new HashMap<>();
        SalableProduct[] products = storeFront.getSalableProducts();
        for (SalableProduct product : products) {
            inventory.put(product.getName(), product.getQuantity());
        }
    }

    /**
     * Returns the quantity of the product with the given name in the inventory
     *
     * @param productName the name of the product to get the quantity for
     * @return the quantity of the product in the inventory
     */
    public int getQuantity(String productName) {
        return inventory.getOrDefault(productName, 0);
    }

    /**
     * Updates the quantity of the product with the given name in the inventory
     *
     * @param productName the name of the product to update the quantity for
     * @param quantity    the new quantity of the product in the inventory
     */
    public void updateQuantity(String productName, int quantity) {
        inventory.put(productName, quantity);
    }

    /**
     * Decrements the quantity of the product with the given name in the inventory by the specified amount
     *
     * @param productName the name of the product to decrement the quantity for
     * @param amount      the amount to decrement the quantity by
     */
    public void decrementQuantity(String productName, int amount) {
        int currentQuantity = getQuantity(productName);
        if (currentQuantity >= amount) {
            updateQuantity(productName, currentQuantity - amount);
        }
    }

    /**
     * Increments the quantity of the product with the given name in the inventory by the specified amount
     *
     * @param productName the name of the product to increment the quantity for
     * @param amount      the amount to increment the quantity by
     */
    public void incrementQuantity(String productName, int amount) {
        int currentQuantity = getQuantity(productName);
        updateQuantity(productName, currentQuantity + amount);
    }
}
