package storeContents;
import java.util.ArrayList;
import java.util.List;

import storeApp.SalableProduct;

/**

The ShoppingCart class represents a shopping cart that stores a list of SalableProduct items.
*/

public class ShoppingCart {
    /**
    * The list of SalableProduct items in the shopping cart.
    */
    
    private List<SalableProduct> items;

   
    /**
     * Constructs an empty shopping cart.
     */
    public ShoppingCart() {
        items = new ArrayList<>();
    }
    
    /**
     * Adds a SalableProduct item to the shopping cart.
     * @param item the SalableProduct item to add
     */

    public void addItem(SalableProduct item) {
        items.add(item);
    }
    
    /**
     * Removes a SalableProduct item from the shopping cart.
     * @param item the SalableProduct item to remove
     */

    public void removeItem(SalableProduct item) {
        items.remove(item);
    }
    
    /**
     * Returns the list of SalableProduct items in the shopping cart.
     * @return the list of SalableProduct items
     */

    public List<SalableProduct> getItems() {
        return items;
    }
    
    /**
     * Calculates and returns the total price of all the items in the shopping cart.
     * @return the total price of all the items in the shopping cart
     */

    public int getTotal() {
        int total = 0;
        for (SalableProduct item : items) {
            total += item.getPrice();
        }
        return total;
    }

    /**
     * Removes all the items from the shopping cart.
     */
    public void clear() {
        items.clear();
    }
    
    /**
     * Checks if the shopping cart is empty.
     * @return true if the shopping cart is empty, false otherwise
     */

    public boolean isEmpty() {
        return items.isEmpty();
    }
}
